---
title: "VCF 9 Deployment Flow: From Bare Metal to Production-Ready Private Cloud in Hours, Not Weeks"
date: 2026-06-18T09:00:00+02:00
series: ["VCF 9"]
tags: ["VCF9", "VMware", "PrivateCloud", "CloudInfrastructure", "Broadcom"]
cover:
  image: "/images/vcf9-deployment-flow.jpg"
  alt: "VCF 9 deployment flow diagram, step by step from bare metal to running cloud"
  caption: "VCF 9 deployment flow: eight stages from physical infrastructure to Day-2 operations"
  relative: false
summary: "The VCF Installer replaces Cloud Builder with a lightweight OVA that automates the entire deployment sequence: vSphere, NSX, VCF Operations, VCF Automation, and the Management Domain, with pre-flight validation and a fully exportable JSON spec."
---

Deploying a private cloud used to mean weeks of spreadsheets, manual configuration, and hoping nothing breaks at Day 0. VCF 9 changes that with a structured, eight-stage deployment flow.

## 1. Prepare Physical Infrastructure

Minimum four ESXi-capable hosts, two physical NICs minimum, vSAN-ready nodes recommended. ToR switches need min four VLANs for Mgmt, vMotion, vSAN, and Edge overlay. DNS, NTP, DHCP, and Active Directory or SSO need to be pre-registered before anything else starts.

## 2. Deploy the VCF Installer

The VCF Installer is the headline change in VCF 9: a lightweight OVA appliance that replaces Cloud Builder entirely. It runs outside the Management Domain, which means it can be reused for multiple single-deployment cycles instead of being a one-shot tool. Minimum spec is four vCPU, 16GB RAM, and 150GB storage, with static IP, FQDN, and NTP/DNS required before deployment.

## 3. Upload Software Binaries

Two paths here: online depot, authenticated to the Broadcom Support Portal directly, or offline/air-gapped, importing bundles manually through a proxy or offline depot. Required bundles are vSphere ESXi, vCenter Server, NSX, SDDC Manager, VCF Operations, and VCF Automation. Optional add-ons include HCX, VCF Ops for Logs, and VCF Ops for Networks.

## 4. Provide Deployment Configuration

This is where the bulk of the planning work lives: compute host FQDNs and root credentials with SSH fingerprints confirmed for each host, networking VLANs and overlay segments, storage type selection (vSAN ESA, vSAN OSA, NFS, FC, or NVMe over Fabric), and the full IP and identity plan covering DNS, NTP, vCenter, NSX, and SDDC Manager FQDNs.

## 5. Deploy VCF 9 (One-Click)

Once configuration is validated, deployment runs in four automated phases: vSphere first (hosts commissioned, management cluster deployed), then NSX (Manager cluster and Edge cluster with Host TEP configured), then VCF Operations and Logs, and finally VCF Automation with the Management Domain created and SDDC Manager active. This entire sequence is fully automated by the Installer — no manual intervention between phases.

## 6. Management Domain Ready

At this point you have a working private cloud: vCenter, NSX Manager x3, SDDC Manager, VCF Operations and Automation all live. NSX Edge cluster has T-0/T-1 routing and segments configured. vSAN is policy-enabled with encryption, and centralized licensing and compliance visibility are active through SDDC Manager.

## 7. Create Workload Domains

From here, Workload Domains scale on demand. You can go Greenfield, building a new VI Workload Domain from scratch, or import an existing vCenter to converge it into VCF. NSX can be shared with the Management Domain or dedicated per domain depending on isolation requirements, and domains can scale independently with their own policies and resource isolation.

## 8. Operate and Manage VCF 9 Cloud

Day-2 operations run centrally: VCF Operations for capacity planning and cost visibility, VCF Automation for self-service IaaS onboarding and infrastructure as code, Lifecycle management for fleet-wide patching and driver updates, and a Security Ops dashboard for hardening, backup, and DR integration.

## Why This Matters

Pre-flight validation catches configuration issues before a single line executes, and the full deployment spec is exportable as JSON, giving you both repeatability across sites and an audit trail for compliance. The practical result: a production-ready Management Domain — vSAN, NSX Edge, unified operations — standing up in hours instead of weeks.

---

*This is the second post in the VCF 9 series. The first covered the [architecture overview]({{< ref "01-vcf9-architecture-overview.md" >}}) — Fleet, Instance, Management Domain, and VI Workload Domain layers.*
