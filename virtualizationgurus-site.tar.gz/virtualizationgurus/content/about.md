---
title: "About"
hidemeta: true
---

I'm a Senior Cloud Infrastructure / Multi-Cloud Consultant working primarily in VMware Cloud Foundation (VCF), NSX, vSAN, and multi-cloud platforms including OCI and GCP. My background spans VMware PS CCoE as an SRE, 50+ VCF deployments, and hands-on multi-cloud consulting work bridging traditional private cloud and hyperscaler environments.

Virtualization Gurus is where I write the technical content I wish existed when I was building these environments myself — deployment walkthroughs, architecture breakdowns, and the operational detail that usually gets left out of vendor documentation.

Certifications: VCIX-DCV, VCP-NV, VCF Specialist, VCF Administrator and Architect 9.0, vSAN Specialist.

Connect with me on [LinkedIn](https://www.linkedin.com/).
