# Virtualization Gurus

Technical blog on VMware Cloud Foundation 9, NSX, vSAN, and multi-cloud
private cloud architecture. Built with Hugo + PaperMod.

## Local development

    hugo server -D

## Build

    hugo --minify

Output goes to `public/`.

## Deploy

This site is set up for GitHub Pages via Actions, or any static host
(Cloudflare Pages, Netlify, Vercel). Set `baseURL` in `hugo.toml` to
your live domain before deploying.

## Adding a post

    hugo new content posts/03-fleet-management-layer.md

Set `series: ["VCF 9"]` in the front matter to keep it grouped under
the VCF 9 series page, and add a `cover.image` pointing to
`/images/<filename>.jpg` for the matching whiteboard diagram.
